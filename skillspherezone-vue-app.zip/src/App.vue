<template>
  <div class="app">
    <header class="header">
      <h1>SkillSphereZone</h1>
      <p>Learn new skills. Grow your knowledge. Share your journey.</p>
    </header>

    <nav class="nav">
      <a href="#">Home</a>
      <a href="#">Blog</a>
      <a href="#">About</a>
      <a href="#">Contact</a>
    </nav>

    <div class="language-switcher">
      <button @click="switchLanguage('en')">English</button>
      <button @click="switchLanguage('ur')">Urdu</button>
    </div>

    <div class="search-bar">
      <input v-model="searchQuery" placeholder="Search..." />
    </div>

    <div class="container">
      <transition-group name="fade" tag="div">
        <div v-for="(post, index) in filteredPosts" :key="index" class="post">
          <h2>{{ post.title }}</h2>
          <img :src="post.image" :alt="post.title" />
          <p>{{ post.content }}</p>
        </div>
      </transition-group>
    </div>

    <footer class="footer">
      <p>&copy; 2025 SkillSphereZone. All rights reserved.</p>
    </footer>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const posts = ref([]);
const currentLang = ref('en');
const searchQuery = ref('');

// Load posts from external JSON file
onMounted(async () => {
  try {
    const res = await fetch('/posts.json');
    const data = await res.json();
    posts.value = data;
  } catch (e) {
    console.error('Failed to load posts:', e);
  }
});

function switchLanguage(lang) {
  currentLang.value = lang;
}

const filteredPosts = computed(() => {
  return posts.value.filter(post =>
    post.lang === currentLang.value &&
    (post.title.toLowerCase().includes(searchQuery.value.toLowerCase()) ||
     post.content.toLowerCase().includes(searchQuery.value.toLowerCase()))
  );
});
</script>

<style scoped>
body {
  margin: 0;
  font-family: 'Poppins', 'Noto Nastaliq Urdu', sans-serif;
  background: url('https://source.unsplash.com/1600x900/?technology,background') no-repeat center center fixed;
  background-size: cover;
  color: #333;
}
.header {
  background: rgba(0, 0, 0, 0.6);
  color: white;
  padding: 2rem;
  text-align: center;
}
.nav {
  background-color: #2d2d2d;
  display: flex;
  justify-content: center;
  padding: 1rem 0;
}
.nav a {
  color: white;
  margin: 0 1.5rem;
  text-decoration: none;
  font-weight: 500;
}
.language-switcher {
  text-align: center;
  margin: 1rem;
}
.language-switcher button {
  margin: 0 10px;
  padding: 0.5rem 1rem;
  background-color: #6A82FB;
  border: none;
  color: white;
  border-radius: 5px;
  cursor: pointer;
  font-weight: 500;
}
.search-bar {
  text-align: center;
  margin: 1rem;
}
.search-bar input {
  padding: 0.5rem;
  width: 60%;
  max-width: 400px;
  border-radius: 5px;
  border: 1px solid #ccc;
}
.container {
  max-width: 1000px;
  margin: 2rem auto;
  padding: 1rem;
  background-color: rgba(255, 255, 255, 0.9);
  border-radius: 10px;
}
.post {
  margin-bottom: 3rem;
}
.post img {
  width: 100%;
  border-radius: 10px;
  margin: 1rem 0;
}
.post h2 {
  color: #FC5C7D;
  margin-bottom: 0.5rem;
}
.footer {
  background-color: #2d2d2d;
  color: white;
  text-align: center;
  padding: 1rem;
  margin-top: 3rem;
}
.fade-enter-active, .fade-leave-active {
  transition: opacity 0.5s;
}
.fade-enter-from, .fade-leave-to {
  opacity: 0;
}
</style>